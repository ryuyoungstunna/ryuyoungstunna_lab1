import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>🎓 Student Profile</Text>

        <View style={styles.section}>
          <Text style={styles.label}>Name:</Text>
          <Text style={styles.info}>Paul Bernard P. Joveda</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Age:</Text>
          <Text style={styles.info}>21</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Course / Year / Section:</Text>
          <Text style={styles.info}>BS Computer Science - 3rd Year / CS3A</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>About Me:</Text>
          <Text style={styles.info}>
            I’m a passionate computer science student who loves exploring web and mobile development. 
            I enjoy learning modern technologies and solving real-world problems through coding.
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Achievements:</Text>
          <Text style={styles.info}>
            • Dean’s Lister (2023 - 2025){"\n"}
            • Top 5 in Programming Competitions{"\n"}
            • Developed a campus event management app
          </Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Skills:</Text>
          <Text style={styles.info}>
            JavaScript, React Native, Python, Java, UI/UX Design
          </Text>
        </View>

        <Text style={styles.footer}>© 2025 Paul Bernard Joveda</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#e8f5e9', // light green background
    padding: 20,
    flexGrow: 1,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: '#ffffff', // white card
    borderRadius: 20,
    padding: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    elevation: 5,
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: '#2e7d32', // dark green
    marginBottom: 15,
    textAlign: 'center',
  },
  section: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1b5e20',
  },
  info: {
    fontSize: 15,
    color: '#333',
    marginTop: 4,
    lineHeight: 20,
  },
  footer: {
    marginTop: 30,
    textAlign: 'center',
    color: '#4caf50',
    fontSize: 12,
  },
});
