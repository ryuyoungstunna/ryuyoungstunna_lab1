import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, TouchableOpacity } from 'react-native';

export default function App() {
  const [item, setItem] = useState('');
  const [list, setList] = useState([]);

  const addItem = () => {
    if (item.trim() === '') return;
    setList([...list, { id: Date.now().toString(), value: item }]);
    setItem('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🧥 My Favorite Clothing Brands</Text>
      <Text style={styles.subtitle}>
        Add your favorite brands below 👇
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Enter Item"
        value={item}
        onChangeText={setItem}
      />

      <TouchableOpacity style={styles.button} onPress={addItem}>
        <Text style={styles.buttonText}>ADD</Text>
      </TouchableOpacity>

      <FlatList
        data={list}
        renderItem={({ item }) => (
          <View style={styles.listItem}>
            <Text style={styles.listText}>👕 {item.value}</Text>
          </View>
        )}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E8ECF1',
    alignItems: 'center',
    justifyContent: 'flex-start',
    padding: 20,
    paddingTop: 70,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2A2D34',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: '#4A4E56',
    marginBottom: 20,
  },
  input: {
    borderColor: '#7A8BA3',
    borderWidth: 1,
    borderRadius: 10,
    width: '80%',
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
  },
  button: {
    backgroundColor: '#2A9D8F',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 10,
    marginBottom: 20,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  listItem: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 10,
    marginVertical: 5,
    width: '80%',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  listText: {
    fontSize: 16,
    color: '#2A2D34',
  },
});
